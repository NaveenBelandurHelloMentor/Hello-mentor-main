"use client";
import React from "react";
import { useState, useEffect } from "react";
import CardSvg from "../login/LoginSvg/cardsvg";
import Hellomentorsvg from "../login/LoginSvg/hellomentorsvg";
import SearchSvg from './ReferalSvg/searchsvg'
import style from "./page.module.css";
import FirstSvg from './ReferalSvg/FirstSvg'

const RegisterPage = () => {
  const [countreferance, setreferance] = useState(1);
  const [openreferance, setOpenreferance] = useState(false);

  useEffect(() => {
    const intervalRegister = setInterval(() => {
      setreferance(countreferance + 1);
      if (countreferance) {
        if (openreferance == false) {
          setOpenreferance(true);
        } else if (openreferance == true) {
          setOpenreferance(false);
        }
      }
    }, 9000);
    return () => clearInterval(intervalRegister);
  }, [countreferance]);

  return (
    <>
      <section className={style.mainContainer}>
        <div className={style.container}>
          <div className={style.firstcard}>
            <div className={style.firstbox_}>
                  <div className={style.subcontainer}>
                    <CardSvg />

                    
                    
                        <div className={style.firstcontainer}>
                     <SearchSvg/> <p className={style.textreferal}>Choice Filling</p>
                    </div>
                     
                     <div className={style.firstsvgcontainer}>
                       <FirstSvg/> 
                     </div>
                     <div className={style.secondsvgcontainer}>
                       <FirstSvg/> 
                     </div>
                     
              
    
                  </div>

          
              <div className={style.lastbox_}>
                <h2 className={style.lastboxtext}>Choose your College</h2>
                <p className={style.lastbox__}>
                  We are here to assist you in achieving your dream medical
                  seat.
                </p>
              </div>
            </div>
          </div>
          <div className={style.secondcard}>
            <div className={style.secondcardcontainer}>
              <div className={style.secondbox}>
                <div className={style.secondheading}>
                  <Hellomentorsvg />
                  <div>
                    <h2 className={style.otphead}>Log in to your account</h2>
                    <p className={style.optpara}>
                      Horem ipsum dolor sit amet, consectetur adipiscing elit.
                    </p>
                  </div>
                </div>
                <div className={style.optauthcontainer}>
                  <p className={style.opttextsecond_}>Enter Phone number</p>
                  <div className={style.inputcontainer}>
                    <div className={style.inputicon}>
                    
                      <p className={style.inputtext_}>+91</p>
                    </div>
                    <input
                      type="text"
                      className={style.inputBox}
                      placeholder=""
                    />
                  </div>
                  <div>
                    <button className={style.btncontainer}>Submit</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default RegisterPage;